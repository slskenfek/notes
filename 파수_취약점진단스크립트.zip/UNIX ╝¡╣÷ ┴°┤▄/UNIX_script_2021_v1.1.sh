#!/bin/sh 

OS=`uname`
WEBPATH=`find /etc/ -name "httpd.conf"`

grepcom=`which grep`
egrepcom=`which egrep`
SAVE_LANG=`env | $grepcom LANG | cut -d '=' -f2`

if [ $OS = Linux ]
	then
		Linux_OS=$(cat /etc/*-release | uniq | egrep "ID=ubuntu" | cut -f2 -d "=")

		if [ "$Linux_OS" = "" ];
			then
				Linux_OS='centos'
				alias echo='echo -e'
				SYS_PATH='/etc/rsyslog.conf'
				SYS_PATH2='/etc/syslog.conf'
			else
				SYS_PATH='/etc/rsyslog.d/50-default.conf'
				SYS_PATH2='/etc/syslog.d/50-default.conf'
		fi
fi

LANG=C
export LANG

alias ls=ls

CREATE_FILE=`hostname`"_Unix_"`date +%m%d`.txt
#CREATE_FILE2=`hostname`"_2_Unix_"`date +%m%d`.txt
CHECK_FILE=`ls ./"$CREATE_FILE" 2>/dev/null | wc -l`

echo  > $CREATE_FILE 2>&1
#echo  > $CREATE_FILE2 2>&1

echo "========================================================================================================" >> $CREATE_FILE 2>&1
echo "                         Copyright (c) 2019 FASOO Co. Ltd. All right Reserved" >> $CREATE_FILE 2>&1                         
echo "========================================================================================================" >> $CREATE_FILE 2>&1

echo "INFO_CHKSTART"  >> $CREATE_FILE 2>&1
echo >> $CREATE_FILE 2>&1

echo "###################################   UNIX Security Check        ######################################" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "############################################ Start Time ################################################"
date
echo " "
echo "############################################ Start Time ################################################" >> $CREATE_FILE 2>&1
date >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "=================================== System Information Query Start ====================================="
echo "=================================== System Information Query Start =====================================" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "#######################################   Kernel Information   #########################################"
echo "#######################################   Kernel Information   #########################################" >> $CREATE_FILE 2>&1
uname -a >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "#########################################   IP Information   ###########################################"
echo "#########################################   IP Information   ###########################################" >> $CREATE_FILE 2>&1
ifconfig -a >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "#########################################   Network Status   ###########################################"
echo "#########################################   Network Status   ###########################################" >> $CREATE_FILE 2>&1
netstat -an | egrep -i "LISTEN|ESTABLISHED" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "#######################################   Routing Information   ########################################"
echo "#######################################   Routing Information   ########################################" >> $CREATE_FILE 2>&1
netstat -rn >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "##########################################   Process Status   ##########################################"
echo "##########################################   Process Status   ##########################################" >> $CREATE_FILE 2>&1
ps -ef >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "##########################################   User Env   ################################################"
echo "##########################################   User Env   ################################################" >> $CREATE_FILE 2>&1
env >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo " " >> $CREATE_FILE 2>&1

echo "##########################################  lsof -i -P  ################################################"
echo "##########################################  lsof -i -P  ################################################" >> $CREATE_FILE 2>&1
lsof -i -P >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo " " >> $CREATE_FILE 2>&1

echo "=================================== System Information Query End ======================================="
echo "=================================== System Information Query End =======================================" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1


echo >> $CREATE_FILE 2>&1
echo "********************************************* START ****************************************************" >> $CREATE_FILE 2>&1
echo >> $CREATE_FILE 2>&1
echo
echo "********************************************* START ****************************************************"
echo
echo >> $CREATE_FILE 2>&1

echo "========================================================================================================" >> $CREATE_FILE 2>&1
echo "========================================================================================================" >> $CREATE_FILE 2>&1
echo >> $CREATE_FILE 2>&1
echo "INFO_CHKEND"  >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-59] ssh 원격접속 허용"  
echo "[U-59] ssh 원격접속 허용"  >> $CREATE_FILE 2>&1
echo "[CHECK]  원격 접속 시 SSH 프로토콜을 사용 했을 경우 양호" >> $CREATE_FILE 2>&1
echo "[U-01] root 계정 원격 접속 제한"  
echo "[U-01] root 계정 원격 접속 제한"  >> $CREATE_FILE 2>&1
echo "[CHECK]  /etc/securetty 에 console, vc, tty, pts 항목이 주석 처리 되어 있거나 아무 값이 없을 경우 양호 " >> $CREATE_FILE 2>&1
echo "[CHECK]  /etc/ssh/sshd_config 에 PermitRootLogin 변수값이 no 경우 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ ssh" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		svcs -a | grep ssh | grep -v "grep" >> $CREATE_FILE 2>&1
		cat /etc/default/login | grep -i console= >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		netstat -an | grep tcp | grep 22 | grep -i "listen" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ssh/sshd_config | grep "PermitRootLogin" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | grep sshd | grep -v "grep" >> $CREATE_FILE 2>&1
		cat /etc/pam.d/login | grep -i pam_securetty.so >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/securetty >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ssh/sshd_config | grep "PermitRootLogin" >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | grep sshd | grep -v "grep" >> $CREATE_FILE 2>&1
		lsuser -a rlogin root >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		netstat -an | grep tcp | grep 22 | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ssh/sshd_config | grep "PermitRootLogin" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | grep sshd | grep -v "grep" >> $CREATE_FILE 2>&1
		cat /etc/securetty | grep -i console >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		netstat -an | grep tcp | grep 22 | grep -i "listen" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/opt/ssh/sshd_config | grep "PermitRootLogin" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-02] 패스워드 복잡성"
echo "[U-02] 패스워드 복잡성"  >> $CREATE_FILE 2>&1
echo "[CHECK]  John the Ripper를 이용해서 크랙킹 필요" >> $CREATE_FILE 2>&1
echo "[CHECK]  패스워드를 영문숫자 혼합 사용하며, 8자리 이상 사용하면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-02" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/shadow > `hostname`_passwd.txt
		cat /etc/shadow >> $CREATE_FILE 2>&1
		;;
	Linux)
		cat /etc/shadow > `hostname`_passwd.txt
		cat /etc/shadow >> $CREATE_FILE 2>&1
		echo "" >> $CREATE_FILE 2>&1
		if [ $Linux_OS = "centos" ]
			then
				if [ `uname -r | grep -o "el[0-9]" | grep -o "[0-9]"` -lt 7 ]
					then
						uname -r >> $CREATE_FILE 2>&1
						echo "" >> $CREATE_FILE 2>&1
						grep -i "pam_cracklib.so" /etc/pam.d/system-auth >> $CREATE_FILE 2>&1
						echo "" >> $CREATE_FILE 2>&1
						grep -i "pam_cracklib.so" /etc/pam.d/system-auth | grep -oE 'minlen=[0-9]*|ucredit=-1|ucredit=[0-9]*|lcredit=-1|lcredit=[0-9]*|dcredit=-1|dcredit=[0-9]*|ocredit=-1|ocredit=[0-9]*' >> $CREATE_FILE 2>&1
					else
						uname -r >> $CREATE_FILE 2>&1
						echo "" >> $CREATE_FILE 2>&1
						grep -i "pam_pwquality.so" /etc/pam.d/system-auth >> $CREATE_FILE 2>&1
						echo "" >> $CREATE_FILE 2>&1
						grep -E "minlen|ucredit|lcredit|dcredit|ocredit" /etc/security/pwquality.conf >> $CREATE_FILE 2>&1
				fi
		fi
		;;
	HP-UX)
		cat /etc/shadow > `hostname`_passwd.txt
		cat /etc/shadow >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/security/passwd > `hostname`_passwd.txt
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/shadow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/security/shadow >> $CREATE_FILE 2>&1
		;;
esac
echo " " >> $CREATE_FILE 2>&1

echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-03] 계정 잠금 임계값 설정"  
echo "[U-03] 계정 잠금 임계값 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  account required /lib/security/pam_tally.so deny=5(권장) no_magic_root reset 이 설정되어 있으면 양호" >> $CREATE_FILE 2>&1
echo "[CHECK]  Redhat 7 이상 pam_faillock.so preauth silent audit deny=5(권장), pam_faillock.so authfail audit deny=5(권장) 설정되어 있으면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-03" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/default/login | grep -i RETRIES >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/security/policy.conf | grep -i LOCK_AFTER_RETRIES >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo "## system-auth ##" >> $CREATE_FILE 2>&1
		grep -iE "deny|reset|faillock" /etc/pam.d/system-auth >> $CREATE_FILE 2>&1
		echo "" >> $CREATE_FILE 2>&1
		echo "## password-auth ##" >> $CREATE_FILE 2>&1
		grep -iE "deny|reset|faillock" /etc/pam.d/password-auth >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/security/user | grep -i loginretries >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /tcb/files/auth/system/default | grep -i "u_maxtries" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/default/security | grep -i "AUTH_MAXTRIES" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-04] 패스워드 파일 보호"
echo "[U-04] 패스워드 파일 보호" >> $CREATE_FILE 2>&1
echo "[CHECK] 패스워드 저장을 /etc/shadow 파일에 저장하면 양호" >> $CREATE_FILE 2>&1
echo "▶▶ u-04" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al /etc/passwd  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/shadow >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/passwd  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/shadow >> $CREATE_FILE 2>&1
		;;
	AIX)
		ls -al /etc/passwd  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/security/passwd >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/passwd >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /tcb/files/auth >> $CREATE_FILE 2>&1
		;;
esac
echo " " $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-05] root 이외의 UID가 '0' 금지"  
echo "[U-05] root 이외의 UID가 '0' 금지"  >> $CREATE_FILE 2>&1
echo "[CHECK]  if exists(UID = 0) except root THEN VUL" >> $CREATE_FILE 2>&1
echo "[CHECK]  root계정과 동일한 UID를 갖는 계정이 존재하지 않을 경우 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-05" >> $CREATE_FILE 2>&1
	awk -F: '$3==0  { print $1 " -> UID=" $3 }' /etc/passwd >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-06] root 계정 su 제한"  
echo "[U-06] root 계정 su 제한"  >> $CREATE_FILE 2>&1
echo "[CHECK]  auth required /lib/security/pam_wheel.so debug group=wheel 라인이 추가되어있으면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-06" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/group >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /bin/su >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /usr/bin/su  >> $CREATE_FILE 2>&1
		;;
	Linux)
		cat /etc/group  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/pam.d/su | grep -i pam_wheel.so >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /bin/su >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /usr/bin/su  >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/group  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/security/user  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /bin/su >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /usr/bin/su  >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/group  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/default/security  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /bin/su >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /usr/bin/su  >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-07] 패스워드 최소 길이 설정"  
echo "[U-07] 패스워드 최소 길이 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  패스워드 최소길이가 8보다 작으면 취약 " >> $CREATE_FILE 2>&1
echo "[CHECK]  Redhat 7 이상 pwquality.conf의 minlen 설정 값 적용 시 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-07" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/default/passwd | grep -i PASSLENGTH >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo "## login.defs ##" >> $CREATE_FILE 2>&1
		cat /etc/login.defs | grep -i PASS_MIN_LEN >> $CREATE_FILE 2>&1
		echo "" >> $CREATE_FILE 2>&1
		echo "## pwquality.conf ##" >> $CREATE_FILE 2>&1
		cat /etc/security/pwquality.conf | grep -i minlen >> $CREATE_FILE 2>&1
		echo "" >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/security/user | grep -i minlen >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/default/security | grep -i MIN_PASSWORD_LENGTH >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-08] 패스워드 최대 사용 기간 설정"  
echo "[U-08] 패스워드 최대 사용 기간 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  최대 사용기간이 90보다 크면 취약 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-08" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/default/passwd | grep -i MAXWEEKS >> $CREATE_FILE 2>&1
		;;
	Linux)
		grep -i "PASS_MAX_DAYS" /etc/login.defs >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/security/user | grep -i maxage >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/default/security | grep -i PASSWORD_MAXDAYS >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-09] 패스워드 최소 사용기간 설정"
echo "[U-09] 패스워드 최소 사용기간 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  패스워드 최소 사용기간이 0 이면 취약 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-09" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/default/passwd | grep -i MINWEEKS  >> $CREATE_FILE 2>&1
		;;
	Linux)
		cat /etc/login.defs | grep -i PASS_MIN_DAYS  >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/security/user | grep -i minage  >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/default/security | grep -i PASSWORD_MINDAYS  >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-10] 불필요한 계정 제거"
echo "[U-10] 불필요한 계정 제거"  >> $CREATE_FILE 2>&1
echo "[CHECK]  수면계정 및 반복된 로그인 실패 확인 " >> $CREATE_FILE 2>&1
echo "[CHECK]  불필요한 계정을 미삭제, 방치 했을 경우 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-10" >> $CREATE_FILE 2>&1
	cat /etc/passwd  >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-11] 관리자 그룹에 최소한의 계정 포함"
echo "[U-11] 관리자 그룹에 최소한의 계정 포함"  >> $CREATE_FILE 2>&1
echo "[CHECK]  MANUAL CHECK" >> $CREATE_FILE 2>&1
echo "[CHECK]  관리자의 그룹에 많은 계정을 했을 경우 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-11" >> $CREATE_FILE 2>&1
	grep -iE "root|system" /etc/group >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-12] 계정이 존재하지 않는 GID 금지"  
echo "[U-12] 계정이 존재하지 않는 GID 금지"  >> $CREATE_FILE 2>&1
echo "[CHECK]  구성원이 존재하지 않는 그룹이 있을경우 취약 " >> $CREATE_FILE 2>&1
echo "[CHECK]  존재하지 않은 계정에 GID 설정을 했을 경우 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-12" >> $CREATE_FILE 2>&1
	cat /etc/group >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-13] 동일한 UID 금지"  
echo "[U-13] 동일한 UID 금지"  >> $CREATE_FILE 2>&1
echo "[CHECK]  동일한 UID가 존재시 취약 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-13" >> $CREATE_FILE 2>&1
	TMP52=`awk -F: '{ print $3 }' /etc/passwd | sort -n | uniq -c | awk -F" " '{ print $1 ":" $2 }' | grep -v ^1 | awk -F: '{ print $2 }'`
	for uid52 in $TMP52
	do
		grep $uid52 /etc/passwd >> $CREATE_FILE 2>&1
	done
	unset TMP52
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-14] 사용자 Shell 점검"
echo "[U-14] 사용자 Shell 점검" >> $CREATE_FILE 2>&1
echo "[CHECK]  로그인이 필요 없는 계정은 쉘을 /bin/false(nologin) 설정 되어 있으면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-14" >> $CREATE_FILE 2>&1
	cat /etc/passwd | egrep "^daemon|^bin|^sys|^adm|^listen|^nobody|^nobody4|^noaccess|^diag|^listen|^operator|^games|^gopher" | grep -v "admin"  >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-15] Session Timeout 설정"  
echo "[U-15] Session Timeout 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK] if (TMOUT >= 60) then OK" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-15" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/default/login | egrep -i "TMOUT|TIMEOUT" >> $CREATE_FILE 2>&1
		;;
	Linux)
		grep -iE "TMOUT|TIMEOUT" /etc/profile >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		grep -iE autologout /etc/csh.login >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		grep -iE autologout /etc/csh.cshrc >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/profile | egrep -i "TMOUT|TIMEOUT"  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/csh.login | grep -i autologout >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/csh.cshrc | grep -i autologout >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/profile | egrep -i "TMOUT|TIMEOUT"  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/csh.login | grep -i autologout >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/csh.cshrc | grep -i autologout >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-16] root 홈, 패스 디렉터리 권한 및 패스 설정"  
echo "[U-16] root 홈, 패스 디렉터리 권한 및 패스 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  PATH 변수내에 '.' 또는 '..'항목 없으면 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-16" >> $CREATE_FILE 2>&1
	echo $PATH >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-17] 파일 및 디렉터리 소유자 설정"  
echo "[U-17] 파일 및 디렉터리 소유자 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  if exists(list) -> VUL  " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-17" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		find /home -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /etc -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /var -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /tmp -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /export -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		;;
	Linux)
		find /home \( -nouser -o -nogroup \) -exec ls -l {} \; >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /etc \( -nouser -o -nogroup \) -exec ls -l {} \; >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /var \( -nouser -o -nogroup \) -exec ls -l {} \; >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /tmp \( -nouser -o -nogroup \) -exec ls -l {} \; >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /export \( -nouser -o -nogroup \) -exec ls -l {} \; >> $CREATE_FILE 2>&1
		;;
	AIX)
		find /home -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /etc -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /var -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /tmp -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /export -nouser -o -nogroup -xdev -ls 2> /dev/null >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		find /home/ \( -nouser -o -nogroup \) -xdev -exec ls -al {} \; 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /etc/ \( -nouser -o -nogroup \) -xdev -exec ls -al {} \; 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /var/ \( -nouser -o -nogroup \) -xdev -exec ls -al {} \; 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /tmp/ \( -nouser -o -nogroup \) -xdev -exec ls -al {} \; 2> /dev/null >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		find /export/ \( -nouser -o -nogroup \) -xdev -exec ls -al {} \; 2> /dev/null >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-18] /etc/passwd 파일 소유자"  
echo "[U-18] /etc/passwd 파일 소유자 및 권한설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  owner:root , 644이하 -> OK " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-18" >> $CREATE_FILE 2>&1
	ls -al /etc/passwd >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-19] /etc/shadow 파일 소유자 및 권한설정"  
echo "[U-19] /etc/shadow 파일 소유자 및 권한설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  owner:root, 400 -> OK " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-19" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al /etc/shadow  >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/shadow  >> $CREATE_FILE 2>&1
		;;
	AIX)
		ls -al /etc/security/passwd  >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ls -al /etc/shadow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /tcb/files/auth >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-20] /etc/hosts 파일 소유자 및 권한 설정"  
echo "[U-20] /etc/hosts 파일 소유자 및 권한 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  owner:root, 600이하 -> OK " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-20" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -lL /etc/hosts >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/hosts >> $CREATE_FILE 2>&1		
		;;
	AIX)
		ls -al /etc/hosts >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ls -al /etc/hosts >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1


echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-21] /etc/(x)inetd.conf 파일 소유자 및 권한 설정"  
echo "[U-21] /etc/(x)inetd.conf 파일 소유자 및 권한 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  owner:root 600이하 -> OK " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-21" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -lL /etc/inetd.conf >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/inetd.conf  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.conf  >> $CREATE_FILE 2>&1		
		;;
	AIX)
		ls -al /etc/inetd.conf  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.conf  >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ls -al /etc/inetd.conf  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.conf  >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-22] /etc/syslog.conf 파일 소유자 및 권한설정"  
echo "[U-22] /etc/syslog.conf 파일 소유자 및 권한설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  owner:root, 644 -> OK " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-22" >> $CREATE_FILE 2>&1
#	ls -lL /etc/syslog.conf >> $CREATE_FILE 2>&1
#	ls -al $SYS_PATH2 >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
#	ls -al $SYS_PATH >> $CREATE_FILE 2>&1


case $OS in
	SunOS)
		ls -lL /etc/syslog.conf >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/rsyslog.conf >> $CREATE_FILE 2>&1
		ls -al /etc/syslog.conf >> $CREATE_FILE 2>&1		
		;;
	AIX)
		ls -al /etc/syslog.conf >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ls -al /etc/syslog.conf >> $CREATE_FILE 2>&1
		;;
esac

echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1


echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-23] /etc/services 파일 소유자 및 권한설정"  
echo "[U-23] /etc/services 파일 소유자 및 권한설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  owner:root, Permission:644 -> OK " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-23" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
	  ls -lL /etc/services >> $CREATE_FILE 2>&1
		;;
	Linux)
	  ls -al /etc/services >> $CREATE_FILE 2>&1		
		;;
	AIX)
	  ls -al /etc/services >> $CREATE_FILE 2>&1
		;;
	HP-UX)
	  ls -al /etc/services >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-24] SUID, SGID, Sticky bit 설정 파일 점검"  
echo "[U-24] SUID, SGID, Sticky bit 설정 파일 점검"  >> $CREATE_FILE 2>&1
echo "[CHECK]   " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-24" >> $CREATE_FILE 2>&1
	find /usr/ -user root -type f \( -perm -04000 -o -perm -02000 \) -xdev -exec ls -al  {}  \; >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	find /sbin/ -user root -type f \( -perm -04000 -o -perm -02000 \) -xdev -exec ls -al  {}  \; >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	find /opt/ -user root -type f \( -perm -04000 -o -perm -02000 \) -xdev -exec ls -al  {}  \; >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-25] 사용자, 시스템 시작파일 및 환경파일 소유자 및 권한 설정"  
echo "[U-25] 사용자, 시스템 시작파일 및 환경파일 소유자 및 권한 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  Owner : root && 644 이하 일 경우 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-25" >> $CREATE_FILE 2>&1
echo "[# 1. /etc/profile #]" >> ./$CREATE_FILE 2>&1
ls -alL /etc/profile >> ./$CREATE_FILE 2>&1

HOMEDIRS=`grep -vE "nologin|false|#" /etc/passwd | awk -F: 'length($6) > 0 {print $6}' | sort -u`
FILES=".profile .cshrc .kshrc .login .bash_profile .bashrc .bash_login .exrc .netrc .history .sh_history .bash_history .dtprofile"
for dir in $HOMEDIRS
do
	for file in $FILES
	do
		FILE=$dir/$file
		if test -e $FILE
		then
			echo "[# 2. $dir #]" >> ./$CREATE_FILE 2>&1
			ls -alL $FILE >> ./$CREATE_FILE 2>&1
		fi
	done
done
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-26] world writable 파일 점검"  
echo "[U-26] world writable 파일 점검"  >> $CREATE_FILE 2>&1
echo "[CHECK] " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-26" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		find / -xdev -perm -2 -ls | grep -v 'lrwxrwxrwx' | grep -v 'srwxrwxrwx' | grep -v 'srw-rw-rw-' | tail -15000    >> $CREATE_FILE 2>&1
		;;
	Linux)
		find / -xdev -type f -perm -2 -exec ls -l {} \; >> $CREATE_FILE 2>&1
		;;
	AIX)
		find / -xdev -perm -2 -ls | grep -v 'lrwxrwxrwx' | grep -v 'srwxrwxrwx' | grep -v 'srw-rw-rw-' | grep -v 'crw-rw-rw-' | grep -v '/dev/' | grep -v 'drwxrwxrwt' | tail -15000   >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		find / -perm -2 | grep -v "/var/opt/dce/rpc/local" | grep -v "/var/opt/dsau/tmp" | grep -v "/var/opt/cifsclient/" | grep -v "/var/opt/wbem/" | grep -v "/var/opt/hpservices/contrib/SysInfo" | grep -v "/dev/" | grep -v "/var/spool/" | grep -v "/tmp/" | grep -v "/var/opt/dce/security/" | grep -v "/var/tmp" | grep -v "/var/adm/streams" | grep -v "/var/home" | grep -v "/var/evm/sockets/evmd" | grep -v "/var/vx/isis/vea_portal" | grep -v "/var/stm/logs/ui_activity_log" | grep -v "/var/stm/catalog" | grep -v "/var/news" | grep -v "/var/asx" | grep -v "/var/asx/.serverlist" | grep -v "/var/jail/wp_internet/tmp" | grep -v "/var/preserve" | grep -v "/sbin/fsdaemondir/SOCKETS/fsdaemonSocket" | grep -v "/tmp" | grep -v "/etc/useracct/utmpd_read" | grep -v "/var/jail/wp_intranet/tmp" | tail -15000   >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-27] /dev에 존재하지 않는 device 파일 점검"  
echo "[U-27] /dev에 존재하지 않는 device 파일 점검"  >> $CREATE_FILE 2>&1
echo "[CHECK]  " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-27" >> $CREATE_FILE 2>&1
	find /dev -type f -exec ls -l {} \; >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "[U-38] r계열 서비스 비활성화"  
echo "[U-38] r계열 서비스 비활성화"  >> $CREATE_FILE 2>&1
echo "[CHECK] :rsh, rlogin, rexec (shell, login, exec) 서비스가 비활성화 되어있거나 결과값이 없을경우에 양호" >> $CREATE_FILE 2>&1
echo "[U-28] $HOME/.rhosts, hosts.equiv 사용 금지"  
echo "[U-28] $HOME/.rhosts, hosts.equiv 사용 금지"  >> $CREATE_FILE 2>&1
echo "[CHECK]   파일이 존재하지 않으면 OK, 부득이한 경우 권한이 600 이면 OK" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ r-services" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		svcs -a | egrep "shell|rlogin|rexec" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		inetadm | egrep "shell|rlogin|rexec" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/xinetd.d | grep -i "rsh" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/rsh | grep -i "disable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.d | grep -i "rsh" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/rsh | grep -i "disable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.d | grep -i "rlogin" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/rlogin | grep -i "disable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.d | grep -i "rexec" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/rexec | grep -i "disable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/inetd.conf >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/inetd.conf | egrep -i "rsh|login|exec" | egrep -v "grep|klogin|kshell|kexec" >> $CREATE_FILE 2>&1		
		;;
	AIX)
		cat /etc/inetd.conf | grep rlogin  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/inetd.conf | egrep -i "rsh|login|exec" | egrep -v "grep|klogin|kshell|kexec" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/inetd.conf | egrep -i "rsh|login|exec" | egrep -v "grep|klogin|kshell|kexec" >> $CREATE_FILE 2>&1
		;;
esac

if test -e /etc/hosts.equiv
then
	ls -al /etc/hosts.equiv >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	cat /etc/hosts.equiv >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	HOMEDIRS=`cat /etc/passwd | awk -F":" 'length($6) > 0 {print $6}' | sort -u`	
	for dir in $HOMEDIRS
	do
		if test -e $dir/.rhosts
		then
			echo "[# $dir #]" >> $CREATE_FILE 2>&1
			ls -la $dir/.rhosts >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat $dir/.rhosts >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
		else
			echo $dir/.rhosts "does not exists" >> $CREATE_FILE 2>&1
		fi
	done

	unset HOMEDIRS
else
	echo "No such" >> $CREATE_FILE 2>&1
fi

echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-29] 접속 IP 및 포트 제한"  
echo "[U-29] 접속 IP 및 포트 제한"  >> $CREATE_FILE 2>&1
echo "[CHECK]  서버로 접속하는 접속 IP 를 설정했을 경우 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-29" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo "/etc/hosts.deny" >> $CREATE_FILE 2>&1
		cat /etc/hosts.deny  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "/etc/hosts.allow" >> $CREATE_FILE 2>&1
		cat /etc/hosts.allow  >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo "/etc/hosts.deny" >> $CREATE_FILE 2>&1
		cat /etc/hosts.deny  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "/etc/hosts.allow" >> $CREATE_FILE 2>&1
		cat /etc/hosts.allow  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "## firewalld 확인(Redhat 8.0 이상) ##" >> $CREATE_FILE 2>&1
		firewall-cmd --state >> $CREATE_FILE 2>&1
		firewall-cmd --list-all >> $CREATE_FILE 2>&1
		;;
	AIX)
		echo "/etc/hosts.deny" >> $CREATE_FILE 2>&1
		cat /etc/hosts.deny  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "/etc/hosts.allow" >> $CREATE_FILE 2>&1
		cat /etc/hosts.allow  >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo "/var/adm/inetd.sec" >> $CREATE_FILE 2>&1
		cat /var/adm/inetd.sec  >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-30] hosts.lpd 파일 소유자 및 권한설정"  
echo "[U-30] hosts.lpd 파일 소유자 및 권한설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  해당 파일이 없거나 소유주 root && 일반 사용자에게 쓰기 권한이 없으면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-30" >> $CREATE_FILE 2>&1
	ls -al /etc/hosts.lpd >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-31] NIS서비스 비활성화"  
echo "[U-31] NIS서비스 비활성화"  >> $CREATE_FILE 2>&1
echo "[CHECK]  NIS disable이거나 결과가 없으면 양호" >> $CREATE_FILE 2>&1	
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-31" >> $CREATE_FILE 2>&1
	ps -ef | grep -i yp | grep -v "grep" >> $CREATE_FILE 2>&1
	svcs -a | grep yp >> $CREATE_FILE 2>&1
echo "END " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo "[U-32] UMASK 설정 관리"  
echo "[U-32] UMASK 설정 관리"  >> $CREATE_FILE 2>&1
echo "[CHECK]   umask 설정값이 0022 or 0077일 경우 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-32" >> $CREATE_FILE 2>&1
	umask >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-33] 홈 디렉토리 소유자 및 권한 설정"  
echo "[U-33] 홈 디렉토리 소유자 및 권한 설정"  >> $CREATE_FILE 2>&1 
echo "[CHECK]  /etc/passwd에 나와있는 홈디렉토리 존재 양호, 미존재 취약 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-33" >> $CREATE_FILE 2>&1
        cat /etc/passwd  >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	HOMEDIRS=`awk -F: 'length($6) > 0 {print $6}' /etc/passwd | sort -u | grep -vE "#|/tmp|uucppublic"`
		for dir in $HOMEDIRS
			do
				ls -dal $dir >> $CREATE_FILE 2>&1
			done
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-34] 홈 디렉토리로 지정한 디렉토리 존재 관리"  
echo "[U-34] 홈 디렉토리로 지정한 디렉토리 존재 관리"  >> $CREATE_FILE 2>&1
echo "[CHECK]  홈 디렉토리에 지정한 디렉토리가 있는지 확인하고, 불법적인 거나 의심스러운 디렉토리가 존재하면 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-34" >> $CREATE_FILE 2>&1
	awk -F: '{print $1 " -> dir= " $6}' /etc/passwd >> $CREATE_FILE 2>&1
	for dir in $HOMEDIRS
		do
			ls -dal $dir >> $CREATE_FILE 2>&1
		done
	unset HOMEDIRS
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-35] 숨겨진 파일 및 디렉토리 검색 및 제거"  
echo "[U-35] 숨겨진 파일 및 디렉토리 검색 및 제거"  >> $CREATE_FILE 2>&1
echo "[CHECK]   수동체크" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-35" >> $CREATE_FILE 2>&1
	find /home/ -xdev -type f -name ".*" -print >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	find /home/ -xdev -type d -name ".*" -print >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-36] Finger 서비스 비활성화"  
echo "[U-36] Finger 서비스 비활성화"  >> $CREATE_FILE 2>&1
echo "[CHECK]  Finger 서비스가 작동하지 않을경우 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-36" >> $CREATE_FILE 2>&1
if [ `ps -ef | egrep -i "[f]inger|finger" | grep -v "grep" | wc -l` -eq 0 ]
	then
		echo "Finger 서비스가 실행중이 아닙니다." >> $CREATE_FILE 2>&1
	else
		ps -ef | egrep -i "[f]inger|finger" | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | grep finger | grep online >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
	  cat /etc/inetd.conf | egrep -i "finger" >> $CREATE_FILE 2>&1
	  cat /etc/xinetd.d/finger | grep -i "service finger" >> $CREATE_FILE 2>&1
	  cat /etc/xinetd.d/finger | grep -i "disable" >> $CREATE_FILE 2>&1
	  netstat -a | grep LISTEN | grep finger >> $CREATE_FILE 2>&1
fi	
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-39] cron파일 소유자 및 권한 설정"  
echo "[U-39] cron파일 소유자 및 권한  설정"  >> $CREATE_FILE 2>&1
echo "[CHECK] : 소유자가 root 또는 bin이면서 640 이하 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-39" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al /etc/cron.d/cron.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/cron.d/cron.deny >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/crontab >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/cron.daily/* >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/cron.hourly/* >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/cron.monthly/* >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/cron.weekly/* >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /var/spool/cron/* >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/cron.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/cron.deny >> $CREATE_FILE 2>&1
		;;
	AIX)
		ls -al /var/adm/cron/cron.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /var/adm/cron/cron.deny >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ls -al /var/adm/cron/cron.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /var/adm/cron/cron.deny >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-40] DoS 공격에 취약한 서비스 비활성화"  
echo "[U-40] DoS 공격에 취약한 서비스 비활성화 작성 필요"  >> $CREATE_FILE 2>&1
echo "[CHECK] :echo, discard, daytime, chargen 서비스가 비활성화 되어있거나 결과값이 없을경우에 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-40" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		svcs -a | egrep "echo|daytime|discard|chargen" | grep -v "grep" >> $CREATE_FILE 2>&1
		inetadm | egrep "echo|discard|daytime|chargen" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
		cat /etc/inetd.conf | egrep "echo|discard|daytime|chargen" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1		
		cat /etc/xinetd.d | egrep "echo|discard|daytime|chargen" >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/inetd.conf | egrep "echo|discard|daytime|chargen" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/inetd.conf | egrep "echo|discard|daytime|chargen" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-41] NFS 서비스 비활성화"  
echo "[U-41] NFS 서비스 비활성화"  >> $CREATE_FILE 2>&1
echo "[CHECK] : NFS 서비스이 없거나 showmount값이 없으면 양호" >> $CREATE_FILE 2>&1
echo "[U-42] NFS 접근통제"  
echo "[U-42] NFS 접근통제"  >> $CREATE_FILE 2>&1
echo "[CHECK] : 파일 시스템에 대한 호스트별 권한 설정 or NFS 서비스 비실행 or /etc/exports !=everyone 일 경우 -> 양호" >> $CREATE_FILE 2>&1
echo "[U-68] NFS 설정 파일 접근 권한"  
echo "[U-68] NFS 설정 파일 접근 권한" >> $CREATE_FILE 2>&1
echo "[CHECK] : /etc/dfs/dfstab 또는 /etc/exports 가 없거나 퍼미션이 644이하인 경우 -> OK" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ NFS" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | grep -E "nfs|statd|lockd" | grep -v "grep" >> $CREATE_FILE 2>&1
		inetadm | egrep "nfs|statd|lockd" | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | egrep "nfs|statd|lockd" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/dfs/dfstab >> $CREATE_FILE 2>&1
		cat /etc/dfs/sharetab >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/dfs/dfstab >> $CREATE_FILE 2>&1
		ls -al /etc/dfs/sharetab >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | grep -E "nfs|statd|lockd" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/exports >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/exports >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | grep -E "nfs|statd|lockd" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/exports >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/exports >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | grep -E "nfs|statd|lockd" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/dfs/dfstab >> $CREATE_FILE 2>&1
		cat /etc/dfs/sharetab >> $CREATE_FILE 2>&1
		cat /etc/exports >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/dfs/dfstab >> $CREATE_FILE 2>&1
		ls -al /etc/dfs/sharetab >> $CREATE_FILE 2>&1
		ls -al /etc/exports >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-43] automountd 제거"  
echo "[U-43] automountd 제거"  >> $CREATE_FILE 2>&1
echo "[CHECK] : automountd 서비스가 구동중이지 않으면 양호" >> $CREATE_FILE 2>&1
echo "▶▶ u-43" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | grep automount | grep -v "grep" >> $CREATE_FILE 2>&1
	        svcs -a | egrep "autofs" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
	        ps -ef | grep automount | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	AIX)
	        ps -ef | grep automount | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
	        ps -ef | grep automount | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-44] RPC 서비스 확인"
echo "[U-44] RPC 서비스 확인" >> $CREATE_FILE 2>&1
echo "[CHECK]  불필요한 RPC 관련 서비스가 존재하지 않으면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-44" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
	        cat /etc/inetd.conf | egrep "rpc.cmsd|rpc.nisd|rpc.pcnfsd|rpc.rwalld|rpc.rusersd|rpc.rquotad|rpc.rstatd|rpc.rexd|rpc.sprayd|rpc.statd|rpc.ttdbserverd|rpc.ypupdated|sadmind|rusersd|walld|sprayd|rstatd|kcms_server|cachefsd|rexd" >> $CREATE_FILE 2>&1
		inetadm | grep rpc | egrep "ttdbserver|rex|rstat|rusers|spray|wall|rquota" | grep -v "grep" >> $CREATE_FILE 2>&1
	        svcs -a | grep rpc | egrep "ttdbserver|rex|rstat|rusers|spray|wall|rquota" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
		cat /etc/inetd.conf | egrep "rpc.cmsd|rpc.nisd|rpc.pcnfsd|rpc.rwalld|rpc.rusersd|rpc.rquotad|rpc.rstatd|rpc.rexd|rpc.sprayd|rpc.statd|rpc.ttdbserverd|rpc.ypupdated|sadmind|rusersd|walld|sprayd|rstatd|kcms_server|cachefsd|rexd" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d | egrep "rpc.cmsd|rpc.nisd|rpc.pcnfsd|rpc.rwalld|rpc.rusersd|rpc.rquotad|rpc.rstatd|rpc.rexd|rpc.sprayd|rpc.statd|rpc.ttdbserverd|rpc.ypupdated|sadmind|rusersd|walld|sprayd|rstatd|kcms_server|cachefsd|rexd" >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/inetd.conf | egrep "rpc.cmsd|rpc.nisd|rpc.pcnfsd|rpc.rwalld|rpc.rusersd|rpc.rquotad|rpc.rstatd|rpc.rexd|rpc.sprayd|rpc.statd|rpc.ttdbserverd|rpc.ypupdated|sadmind|rusersd|walld|sprayd|rstatd|kcms_server|cachefsd|rexd" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/inetd.conf | egrep "rpc.cmsd|rpc.nisd|rpc.pcnfsd|rpc.rwalld|rpc.rusersd|rpc.rquotad|rpc.rstatd|rpc.rexd|rpc.sprayd|rpc.statd|rpc.ttdbserverd|rpc.ypupdated|sadmind|rusersd|walld|sprayd|rstatd|kcms_server|cachefsd|rexd" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-45] NIS, NIS+ 점검"  
echo "[U-45] NIS, NIS+ 점검 작성 필요"  >> $CREATE_FILE 2>&1
echo "[CHECK]  NIS, NIS+ 서비스를 비활성면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-45" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | egrep "ypserv|ypbind|ypxfrd|rpc.yppasswdd|rpc.ypupdated|rpc.nisd" | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | grep nis | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | egrep "ypserv|ypbind|ypxfrd|rpc.yppasswdd|rpc.ypupdated|rpc.nisd" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | egrep "ypserv|ypbind|ypxfrd|rpc.yppasswdd|rpc.ypupdated|rpc.nisd" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | egrep "ypserv|ypbind|ypxfrd|rpc.yppasswdd|rpc.ypupdated|rpc.nisd" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-46] tftp, talk 활성화 여부"  
echo "[U-46] tftp, talk 활성화 여부"  >> $CREATE_FILE 2>&1
echo "[CHECK]  tftp , tallk 서비스를 비활성이면 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-46" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | egrep "tftp|talk" | grep -v "grep" >> $CREATE_FILE 2>&1
		inetadm | egrep "tftp|talk" | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | egrep "tftp|talk" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | egrep "tftp|talk" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/tftp >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/talk >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/ntalk >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | egrep "tftp|talk" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | egrep "tftp|talk" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
esac	
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-47] sendmail 버전 점검"
echo "[U-47] sendmail 버전 점검"  >> $CREATE_FILE 2>&1
echo "[CHECK] : sendmail 버전이 8.13.8 이상이면 양호" >> $CREATE_FILE 2>&1
echo "[U-48] 스팸 메일 릴레이 제한"  
echo "[U-48] 스팸 메일 릴레이 제한"  >> $CREATE_FILE 2>&1
echo "[CHECK] : 스팸 메일 릴레이 방지 설정을 한 경우 양호" >> $CREATE_FILE 2>&1
echo "[U-49] 일반사용자의 sendmail 실행 방지"  
echo "[U-49] 일반사용자의 sendmail 실행 방지"  >> $CREATE_FILE 2>&1
echo "[CHECK] : sendmail 설정 파일이 PrivacyOptions=restrictqrun 으로 설정되거나, 비활성 상태이면 양호" >> $CREATE_FILE 2>&1
echo "[U-69] expn, vrfy 명령어 제한"
echo "[U-69] expn, vrfy 명령어 제한" >> $CREATE_FILE 2>&1
echo "[CHECK]  PricacyOptions=authwarnings, goaway(noexpn,novrfy)를 포함하고 있을경우 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ Sendmail" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | grep sendmail | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | grep sendmail | grep online >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -i "dz" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep "R$\*" | grep "Relaying denied" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -v "^ *#" | egrep -i "O PrivacyOptions|authwarnings|goaway|novrfy|noexpn" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | grep sendmail | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -i "dz" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep "R$\*" | grep "Relaying denied" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -v "^ *#" | egrep -i "O PrivacyOptions|authwarnings|goaway|novrfy|noexpn" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | grep sendmail | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/sendmail.cf | grep -i "dz" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/sendmail.cf | grep "R$\*" | grep "Relaying denied" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/sendmail.cf | grep -v "^ *#" | egrep -i "O PrivacyOptions|authwarnings|goaway|novrfy|noexpn" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | grep sendmail | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -i "dz" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep "R$\*" | grep "Relaying denied" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -v "^ *#" | egrep -i "O PrivacyOptions|authwarnings|goaway|novrfy|noexpn" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
esac	
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-50] DNS 보안 버전 패치"  
echo "[U-50] DNS 보안 버전 패치"  >> $CREATE_FILE 2>&1
echo "[CHECK]  DNS 서비스를 사용하지 않거나, 양호한 버전을 사용하고 있을 경우에 양호(8.4.6, 8.4.7, 9.2.8-P1, 9.3.4-P1, 9.3.5-P1, 9.4.1-P1, 9.4.2-P2, 9.5.0-P1, 9.5.0a6)" >> $CREATE_FILE 2>&1
echo "[U-51] DNS Zone Transfer 설정"  
echo "[U-51] DNS Zone Transfer 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK] : zone 영역 전송이 특정 호스트로 제한 (allow-transfer { IP; }) 되어 있거나 options xfrnets IP가 설정되어 있다면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ DNS" >> $CREATE_FILE 2>&1
if [ $OS = "SunOS" ]
	then
		svcs -a | grep -i "dns" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
fi
ps -ef | grep named | grep -v "grep" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
ls -al /usr/sbin/named >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
strings /usr/sbin/named | grep -i version >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
dig @localhost +short porttest.dns-oarc.net TXT >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
/usr/sbin/named8 -v >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
cat /etc/named.conf | grep "allow-transfer" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
cat /etc/named.boot | grep "xfrnets" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-52] Apache 디렉토리 리스팅 제거"  
echo "[U-52] Apache 디렉토리 리스팅 제거"  >> $CREATE_FILE 2>&1
echo "[CHECK] : httpd.conf 파일의 Directory 부분의 Options에서 Indexes가 설정되어 있지 않으면 양호" >> $CREATE_FILE 2>&1
echo "[U-53] Apache 웹 프로세스 권한 제한"  
echo "[U-53] Apache 웹 프로세스 권한 제한"  >> $CREATE_FILE 2>&1
echo "[CHECK] : 초기 구동된 httpd 서비스을 제외한 웹 프로세스의 소유자가 Root가 아닐경우 && 웹 프로세스 계정이 \bin\false 또는 nologin일 경우 양호" >> $CREATE_FILE 2>&1
echo "[U-54] Apache 상위 디렉토리 접근 금지"  
echo "[U-54] Apache 상위 디렉토리 접근 금지"  >> $CREATE_FILE 2>&1
echo "[CHECK] : AllowOverride 지시자의 옵션이 None 이면 취약, AuthConfig 면 양호" >> $CREATE_FILE 2>&1
echo "[U-55] Apache 불필요한 파일 제거"  
echo "[U-55] Apache 불필요한 파일 제거"  >> $CREATE_FILE 2>&1
echo "[CHECK] : cgi-bin 폴더의 파일 및 manual 폴더의 파일을 삭제했을 경우 양호" >> $CREATE_FILE 2>&1
echo "[U-56] Apache 링크 사용금지"  
echo "[U-56] Apache 링크 사용금지"  >> $CREATE_FILE 2>&1
echo "[CHECK] : Options 중 FollowSymLinks에 aliases가 있으면 취약, 제거 되어 있으면 양호" >> $CREATE_FILE 2>&1
echo "[U-57] Apache 파일 업로드 및 다운로드 제한"  
echo "[U-57] Apache 파일 업로드 및 다운로드 제한 작성 필요"  >> $CREATE_FILE 2>&1
echo "[CHECK] : 파일 업로드 및 다운로드 용량을 제한시 양호. 설정값이 없을시 취약" >> $CREATE_FILE 2>&1
echo "[U-58] Apache 웹 서비스 영역의 분리"  
echo "[U-58] Apache 웹 서비스 영역의 분리"  >> $CREATE_FILE 2>&1
echo "[CHECK] : DocumentRoot 디렉토리가 htdocs가 아닐경우 양호" >> $CREATE_FILE 2>&1
echo "[U-70] Apache 웹서비스 정보 숨김"  
echo "[U-70] Apache 웹서비스 정보 숨김"  >> $CREATE_FILE 2>&1
echo "[CHECK] : 설정값이 없거나 ServerTokens 지시자의 옵션이 Prod가 아닐경우 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ Apache" >> $CREATE_FILE 2>&1
echo "== WEBPATH ==" >> $CREATE_FILE 2>&1
echo $WEBPATH >> $CREATE_FILE 2>&1
echo "== WEBPATH ==" >> $CREATE_FILE 2>&1
if [ `ps -ef | grep httpd | grep -v "grep" | wc -l` -eq 0 ]
	then
		echo "Apache가 실행중이 아닙니다." >> $CREATE_FILE 2>&1
	else
		ps -ef | grep httpd | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | grep http >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		if [ $WEBPATH ]
		   then
			cat $WEBPATH | grep -v "^ *#" | grep "Options" | grep "Indexes" >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat $WEBPATH | grep -v "^ *#" | egrep "User|Group" >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat /etc/passwd >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat $WEBPATH | grep -v "^ *#" | grep "AllowOverride" >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			find /etc/ -name "manual" >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat $WEBPATH | grep -v "^ *#" | grep "Options" | grep "FollowSymLinks" >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat $WEBPATH | grep -v "^ *#" | grep "LimitRequestBody"  >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat $WEBPATH | grep -v "^ *#" | grep "DocumentRoot" >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			cat $WEBPATH | grep -v "^ *#" | grep "ServerToken" >> $CREATE_FILE 2>&1
		fi
fi		
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-37] Anonymous FTP 비활성화" 
echo "[U-37] Anonymous FTP 비활성화" >> $CREATE_FILE 2>&1
echo "[CHECK] : 익명계정에 대한 ftp 접근이 제한(anonymous_enable=NO 또는 주석처리)되어 있으면 양호 " >> $CREATE_FILE 2>&1
echo "[U-60] ftp 서비스 확인"
echo "[U-60] ftp 서비스 확인" >> $CREATE_FILE 2>&1
echo "[CHECK]  /etc/services 에 ftp 21/tcp 를 주석처리하거나 삭제했을 경우 양호  " >> $CREATE_FILE 2>&1
echo "[U-61] ftp 계정 shell 제한"  
echo "[U-61] ftp 계정 shell 제한"  >> $CREATE_FILE 2>&1
echo "[CHECK]  /etc/shells에 임의의 쉘이 추가되어 있고 FTP계정의 Shell 부분이 /bin/false 가 부여된 경우 OK " >> $CREATE_FILE 2>&1
echo "[U-62] ftpusers 파일 소유자 및 권한설정"  
echo "[U-62] ftpusers 파일 소유자 및 권한설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  소유자 root && 640 이하일시 양호" >> $CREATE_FILE 2>&1
echo "[U-63] ftpusers 파일 설정"  
echo "[U-63] ftpusers 파일 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  if exists(/ftpusers) -> OK " >> $CREATE_FILE 2>&1
echo "▶▶ FTP" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/inetd.conf | grep "/usr/sbin/in.ftpd" | grep "in.fingerd" | grep "ftp" | grep "stream" >> $CREATE_FILE 2>&1
		ps -ef | grep proftpd | grep -v "grep" >> $CREATE_FILE 2>&1
		ps -ef | grep vsftpd | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | grep ftp >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/passwd | grep "ftp" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/ftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/proftpd.conf >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/user_list >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.user_list >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/ftpd/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/proftpd.conf | grep -i "RootLogin" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | grep ftp | grep -v "grep" >> $CREATE_FILE 2>&1
		ps -ef | grep vsftpd | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/passwd | grep "ftp" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/ftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/proftpd.conf >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/user_list >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.user_list >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/ftpd/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/proftpd.conf | grep -i "RootLogin" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | grep ftp | grep -v "grep" >> $CREATE_FILE 2>&1
		ps -ef | grep vsftpd | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/passwd | grep "ftp" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/ftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/proftpd.conf >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/user_list >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.user_list >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/ftpd/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/proftpd.conf | grep -i "RootLogin" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | grep ftp | grep -v "grep" >> $CREATE_FILE 2>&1
		ps -ef | grep vsftpd | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/passwd | grep "ftp" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/ftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/proftpd.conf >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.ftpusers >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd/user_list >> $CREATE_FILE 2>&1
		ls -al /etc/vsftpd.user_list >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/ftpd/ftpusers | grep -i "root" >> $CREATE_FILE 2>&1
		cat /etc/proftpd.conf | grep -i "RootLogin" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.ftpusers | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftp/user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.user_list | grep "root" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep "userlist_enable" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-64] at파일 소유자 및 권한설정"  
echo "[U-64] at파일 소유자 및 권한설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  owner:root && Permission:640미만 -> OK " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-64" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al /etc/cron.d/at.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/cron.d/at.deny >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/at.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/at.deny >> $CREATE_FILE 2>&1
		;;
	AIX)
		ls -al /var/adm/cron/at.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /var/adm/cron/at.deny >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ls -al /var/adm/cron/at.allow >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /var/adm/cron/at.deny >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-65] SNMP 서비스 구동 점검"  
echo "[U-65] SNMP 서비스 구동 점검"  >> $CREATE_FILE 2>&1
echo "[CHECK] : SNMP가 구동되고 있지 않으면 양호" >> $CREATE_FILE 2>&1
echo "[U-66] SNMP 서비스 Community String의 복잡성 설정"  
echo "[U-66] SNMP 서비스 Community String의 복잡성 설정"  >> $CREATE_FILE 2>&1
echo "[CHECK]  SNMP 서비스를 사용하지 않거나 커뮤니티스트링이 public 또는 private이 아닐경우 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SNMP" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | grep snmp | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/snmpd.conf | egrep -i "pupblic|private" >> $CREATE_FILE 2>&1
		cat /etc/snmp/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private"  >> $CREATE_FILE 2>&1
		cat /etc/sma/snmp/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
	        cat /etc/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		cat /etc/snmp/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		cat /etc/snmpdv3.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		cat /etc/snmp/snmpd.conf | egrep -i "public|private" >>$CREATE_FILE 2>&1
		cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-67] 로그온 시 경고 메시지 제공"  
echo "[U-67] 로그온 시 경고 메시지 제공"  >> $CREATE_FILE 2>&1
echo "[CHECK] : issue.net && motd 파일의 내용이 기본 설정이거나 없을경우 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-67" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/motd >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/default/telnetd | grep -i "banner" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/default/ftpd | grep -i "banner" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/named.conf | grep -i "version" >> $CREATE_FILE 2>&1
		;;
	Linux)
		cat /etc/motd >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/issue >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/issue >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		ls -al /etc/issue.net >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/issue.net >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/welcome.msg >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/vsftpd.conf | grep -i "ftp_banner" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/proftpd.conf  | grep -i "Serverldent" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/named.conf | grep -i "version" >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/motd >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/security/login.cfg | grep -v '#' | grep -v "*" | grep -i "herald" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1		
		cat /usr/lib/nls/msg/$ftp_LANG1/ftpd.cat >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/sendmail.cf | grep -i "GreetingMessage" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/named.conf | grep -i "version" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/motd >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/inetd.conf | grep "telnetd" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/ftpd/ftpaccess | egrep -i "suppresshostname.yes|suppressversion.yes" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/inetd.conf | grep "ftp" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/issue >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/named.conf | grep -i "version" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-71] 최신 보안패치 및 벤더 권고사항 적용"  
echo "[U-71] 최신 보안패치 및 벤더 권고사항 적용"  >> $CREATE_FILE 2>&1
echo "[CHECK]  InterView " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-71" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		showrev -p >> $CREATE_FILE 2>&1
		;;
	Linux)
		rpm -qa | sort >> $CREATE_FILE 2>&1
		;;
	AIX)
		lslpp -La >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		instfix -iv | grep ML >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		swlist -l product >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================" >> $CREATE_FILE 2>&1
echo "[U-72]  로그의 정기적 검토 및 보고"  
echo "[U-72]  로그의 정기적 검토 및 보고" >> $CREATE_FILE 2>&1
echo "[CHECK]: InterView " >> $CREATE_FILE 2>&1
echo "[CHECK]: 로깅설정 자체가 없으면 취약, 인터뷰시 리포트가 없으면 취약" >> $CREATE_FILE 2>&1
echo "[COUNTERMEASURE]: " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-72" >> $CREATE_FILE 2>&1
echo "InterView" >> $CREATE_FILE 2>&1
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-72] End" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[U-73] 정책에 따른 시스템 로깅 설정"
echo "[U-73] 정책에 따른 시스템 로깅 설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : syslog.conf 또는 rsyslog.conf 파일에 alert,info에 대해서 로그가 남도록 설정되어 있다면 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ u-73" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | grep syslogd | grep -v 'grep' >> $CREATE_FILE 2>&1
		svcs -a | grep system-log | grep -v 'grep' >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "mail|info|alert" | egrep "var|log" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "alert" | egrep "console|root" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "mail|info|alert" | egrep "var|log" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "alert" | egrep "console|root" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/default/su >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | grep syslogd | grep -v 'grep' >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "mail|info|authpriv|cron" | egrep "var|log" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "alert" | egrep "console" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "mail|info|authpriv|cron" | egrep "var|log" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "alert" | egrep "console" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | grep syslogd | grep -v 'grep' >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "mail|info|alert|err|auth|daemon|emerg" | egrep "var|adm" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "alert" | egrep "console" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "mail|info|alert|err|auth|daemon|emerg" | egrep "var|adm" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "alert" | egrep "console" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | grep syslogd | grep -v 'grep' >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "notice" | egrep "var|adm" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "alert" | egrep "console" >> $CREATE_FILE 2>&1
		cat /etc/syslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "notice" | egrep "var|adm" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "alert" | egrep "console" >> $CREATE_FILE 2>&1
		cat /etc/rsyslog.conf | egrep "emerg" | egrep "*" >> $CREATE_FILE 2>&1
		;;
esac
echo " " >> $CREATE_FILE 2>&1

echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "===================2019년 추가========================="  >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-004] 불필요한 SMTP 서비스 실행 여부"
echo "[SRV-004] 불필요한 SMTP 서비스 실행 여부" >> $CREATE_FILE 2>&1
echo "[CHECK] : Local Address에 25포트가 오픈되어 있으면 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-004" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		netstat -an | grep ".25" >> $CREATE_FILE 2>&1
		;;
	Linux)
		netstat -ant | grep ":25" >> $CREATE_FILE 2>&1
		;;
	AIX)
		netstat -an | grep ".25" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		netstat -an | grep ".25" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-006] Sendmail Log Level 미설정"
echo "[SRV-006] Sendmail Log Level 미설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : Sendmail Log Level 설정이 9(예)이하이면 취약" >> $CREATE_FILE 2>&1
echo "[SRV-008] Sendmail 서비스 거부 방지 기능 미설정"
echo "[SRV-008] Sendmail 서비스 거부 방지 기능 미설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : MaxMessageSize(발송)가 10000000(10메가)이하이고 M(수신)이 2048000(2메가)이하면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-006,SRV-008" >> $CREATE_FILE 2>&1
#centos 6.5이상 $SYS_PATH 그 이외에는 /etc/syslog.conf
cat /etc/mail/sendmail.cf | grep -i "LogLevel" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE
cat /etc/mail/sendmail.cf | grep -i "MaxDaemonChildren" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE
cat /etc/mail/sendmail.cf | grep -i "ConnectionRateThrottle" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE
cat /etc/mail/sendmail.cf | grep -i "MinFreeBlocks" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE
cat /etc/mail/sendmail.cf | grep -i "MaxHeadersLength" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE
cat /etc/mail/sendmail.cf | grep -i "MaxMessageSize" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE
cat /etc/mail/sendmail.cf | grep -i "M=" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-012] .netrc 파일 내 호스트 정보 노출"
echo "[SRV-012] .netrc 파일 내 호스트 정보 노출" >> $CREATE_FILE 2>&1
echo "[CHECK] : .netrc의 파일이 600이하로 설정되어 있으면 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-012" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo .netrc 파일 검색 >> $CREATE_FILE 2>&1
		find /home -type f -name ".netrc" -exec ls -al '{}' \; >> $CREATE_FILE 2>&1
		find /home -type f -name ".netrc" -exec cat '{}' \; >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo .netrc 파일 검색  >> $CREATE_FILE 2>&1
		find /home -type f -name ".netrc" -exec ls -al '{}' \; >> $CREATE_FILE 2>&1 
		find /home -type f -name ".netrc" -exec cat '{}' \; >> $CREATE_FILE 2>&1
		;;
	AIX)
		echo .netrc 파일 검색  >> $CREATE_FILE 2>&1
		find /home -type f -name ".netrc" -exec ls -al '{}' \; >> $CREATE_FILE 2>&1 
		find /home -type f -name ".netrc" -exec cat '{}' \; >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo .netrc 파일 검색  >> $CREATE_FILE 2>&1
		find /home -type f -name ".netrc" -exec ls -al '{}' \; >> $CREATE_FILE 2>&1 
		find /home -type f -name ".netrc" -exec cat '{}' \; >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-033] 불필요한 DMI 서비스 구동 여부"
echo "[SRV-033] 불필요한 DMI 서비스 구동 여부" >> $CREATE_FILE 2>&1
echo "[CHECK] : DMI 서비스가 구동되어 있지 않은 경우 양호, 불필요하게 구동되어 있는 경우 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-033" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo dmi, snmpdx, sma 활성화 여부 확인  >> $CREATE_FILE 2>&1
		svcs | grep dmi  >> $CREATE_FILE 2>&1
		svcs | grep snmp	>> $CREATE_FILE 2>&1		
		svcs | grep sma		>> $CREATE_FILE 2>&1
		;;
	Linux)
		echo NA >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo NA >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo NA >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1





echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-039] 불필요한 Tmax WebtoB 서비스 구동 여부"
echo "[SRV-039] 불필요한 Tmax WebtoB 서비스 구동 여부" >> $CREATE_FILE 2>&1
echo "[CHECK] : 결과 값이 없으면 양호, 결과 값이 있다면 프로세스 확인 후 필요없는 프로세스 존재 시 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-039" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo Tmax WebtoB 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep htmls | grep -v grep >> $CREATE_FILE 2>&1
		wsboot -h >> $CREATE_FILE 2>&1 
		;;
	Linux)
		echo Tmax WebtoB 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep htmls | grep -v grep >> $CREATE_FILE 2>&1
		wsboot -h >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo Tmax WebtoB 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep htmls | grep -v grep >> $CREATE_FILE 2>&1
		wsboot -h >> $CREATE_FILE 2>&1 
		;;
	HP-UX)
		echo Tmax WebtoB 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep htmls | grep -v grep >> $CREATE_FILE 2>&1
		wsboot -h >> $CREATE_FILE 2>&1 
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-060] 미흡한 Apache Tomcat 기본 계정 사용 여부"
echo "[SRV-060] 미흡한 Apache Tomcat 기본 계정 사용 여부" >> $CREATE_FILE 2>&1
echo "[CHECK] : 기본 계정  tomcat / both / role1 를 사용 중이면 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-060" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo 프로세스 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep tomcat
		ps -ef | grep tomcat  | grep -v "grep" | cut -f5 -d: | cut -f1 -d " " > fasoo_tom.txt
		B=2
		while true
		do
			C=$(cat fasoo_tom.txt | cut -f $B -d "/")
			if [ "$C" = "bin" ]; then
				echo "---- $D ----" >> $CREATE_FILE 2>&1
				tail -15 $D/conf/tomcat-users.xml >> $CREATE_FILE 2>&1
				break
			elif [ $B -eq 10 ]; then
				break
			fi
			D=$D"/"$C
			B=$(($B+1))
		done 
		rm -rf fasoo_tom.txt
		echo " " >> $CREATE_FILE 2>&1	
		;;
	Linux)
		#find / -type d -name '*tomcat*' -exec tail -15 {}/conf/tomcat-users.xml \; >> $CREATE_FILE 2>&1 
		echo Apache Tomcat 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep tomcat  | grep -v "grep" | cut -f5 -d: | cut -f1 -d " " > fasoo_tom.txt
		B=2
		while true
		do
			C=$(cat fasoo_tom.txt | cut -f $B -d "/")
			if [ "$C" = "bin" ]; then
				echo "---- $D ----" >> $CREATE_FILE 2>&1
				tail -15 $D/conf/tomcat-users.xml >> $CREATE_FILE 2>&1
				break
			elif [ $B -eq 10 ]; then
				break
			fi
			D=$D"/"$C
			B=$(($B+1))
		done 
		rm -rf fasoo_tom.txt
		echo " " >> $CREATE_FILE 2>&1
		;;
	AIX)
		echo Apache Tomcat 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep tomcat  | grep -v "grep" | cut -f5 -d: | cut -f1 -d " " > fasoo_tom.txt
		B=2
		while true
		do
			C=$(cat fasoo_tom.txt | cut -f $B -d "/")
			if [ "$C" = "bin" ]; then
				echo "---- $D ----" >> $CREATE_FILE 2>&1
				tail -15 $D/conf/tomcat-users.xml >> $CREATE_FILE 2>&1
				break
			elif [ $B -eq 10 ]; then
				break
			fi
			D=$D"/"$C
			B=$(($B+1))
		done 
		rm -rf fasoo_tom.txt
		echo " " >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo Apache Tomcat 구동 여부 점검  >> $CREATE_FILE 2>&1
		ps -ef | grep tomcat  | grep -v "grep" | cut -f5 -d: | cut -f1 -d " " > fasoo_tom.txt
		B=2
		while true
		do
			C=$(cat fasoo_tom.txt | cut -f $B -d "/")
			if [ "$C" = "bin" ]; then
				echo "---- $D ----" >> $CREATE_FILE 2>&1
				tail -15 $D/conf/tomcat-users.xml >> $CREATE_FILE 2>&1
				break
			elif [ $B -eq 10 ]; then
				break
			fi
			D=$D"/"$C
			B=$(($B+1))
		done 
		rm -rf fasoo_tom.txt
		echo " " >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[CHECK] : BIND 미 설치 시 양호" >> $CREATE_FILE 2>&1
echo "[SRV-061] DNS Inverse Query 설정 오류"
echo "[SRV-061] DNS Inverse Query 설정 오류" >> $CREATE_FILE 2>&1
echo "[CHECK-61] : BIND 버전 4.9.7이하,8.1.2버전 이하 취약" >> $CREATE_FILE 2>&1
echo "[SRV-062] BIND 서버 버전 노출 여부"
echo "[SRV-062] BIND 서버 버전 노출 여부" >> $CREATE_FILE 2>&1
echo "[CHECK-62] : 버전 값이 나오면 취약. 만약 NS서버이고 값이 없다면 cmd에서 아래 명령어로 진단" >> $CREATE_FILE 2>&1
echo "nslookup -> server [네임서버 도메인] > set class=chaos > set type=txt > version.bind" >> $CREATE_FILE 2>&1
echo "[SRV-063] DNS Recursive Query 설정 미흡"
echo "[SRV-063] DNS Recursive Query 설정 미흡" >> $CREATE_FILE 2>&1
echo "[CHECK-63] : recursion 값이 no 면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-061,SRV-062,SRV-063" >> $CREATE_FILE 2>&1

echo BIND 활성화 여부 확인 >> $CREATE_FILE 2>&1
ps -ef | grep -i "named" | grep -v "grep" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo BIND 서버 버전 확인 >> $CREATE_FILE 2>&1
named -v >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo BIND 서버 버전 노출 여부 확인 >> $CREATE_FILE 2>&1
dig @127.0.0.1 txt chaos version.bind | grep version.bind >> $CREATE_FILE 2>&1 
cat /etc/named.conf | grep version >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo DNS Recursive 설정 확인 >> $CREATE_FILE 2>&1
cat /etc/named.conf | grep recursion >> $CREATE_FILE 2>&1		
echo " " >> $CREATE_FILE 2>&1

echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-075] 유추가능한 비밀번호 사용 여부"
echo "[SRV-075] 유추가능한 비밀번호 사용 여부" >> $CREATE_FILE 2>&1
echo "[CHECK] : 패스워드 복잡도를 검증하며, 결과 값이 없는 경우 취약" >> $CREATE_FILE 2>&1
echo "[CHECK]  Redhat 7 이상 pwquality.conf 확인" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-075" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo 패스워드 복잡도 검증  >> $CREATE_FILE 2>&1
		cat /etc/default/passwd | egrep -i "MINDIFF|MINALPHA|MINNONALPHA|MINUPPER|MINLOWER|MAXREPEATS|MINSPECIAL|MINDIGIT" >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo 패스워드 복잡도 검증  >> $CREATE_FILE 2>&1
		echo "## system-auth ##" >> $CREATE_FILE 2>&1
		cat /etc/pam.d/system-auth | grep -E "minlen|dcredit|ucredit|lcredit|ocredit"  >> $CREATE_FILE 2>&1
		echo "" >> $CREATE_FILE 2>&1
		echo "## common-password ##" >> $CREATE_FILE 2>&1
		cat /etc/pam.d/common-password | grep -E "minlen|dcredit|ucredit|lcredit|ocredit"  >> $CREATE_FILE 2>&1
		echo "" >> $CREATE_FILE 2>&1
		echo "## pwquality.conf ##" >> $CREATE_FILE 2>&1
		cat /etc/security/pwquality.conf | grep -E "minlen|dcredit|ucredit|lcredit|ocredit" >> $CREATE_FILE 2>&1
		;;
	AIX)
		echo 패스워드 복잡도 검증  >> $CREATE_FILE 2>&1
		cat /etc/security/user | $grepcom -v "^*" | $grepcom -E ":|minother|minalpha|mindiff"  >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo 패스워드 복잡도 검증  >> $CREATE_FILE 2>&1
		cat /etc/default/security | $egrepcom "PASSWORD_MIN_UPPER_CASE|PASSWORD_MIN_LOWER_CASE|PASSWORD_MIN_DIGIT_CASE_CHARS|PASSWORD_MIN_SPECIAL_CASE_CHARS" >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-074] 관리되지 않는 계정 및 비밀번호 점검"
echo "[SRV-074] 관리되지 않는 계정 및 비밀번호 점검" >> $CREATE_FILE 2>&1
echo "[CHECK] : 불필요한 계정 제거" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-074" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo "U-10 항목과 동일 " >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo "U-10 항목과 동일 " >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo "U-10 항목과 동일 " >> $CREATE_FILE 2>&1 
		;;
	HP-UX)
		echo "U-10 항목과 동일 " >> $CREATE_FILE 2>&1 
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-081] Crontab 설정파일 권한 설정 오류"
echo "[SRV-081] Crontab 설정파일 권한 설정 오류" >> $CREATE_FILE 2>&1
echo "[CHECK] : U-39 항목과 동일" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-081" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al /etc/ | grep cron   >> $CREATE_FILE 2>&1
		ls -al /etc/cron.d/ | grep cron  >> $CREATE_FILE 2>&1		
		ls -alL /var/spool/cron/*  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /etc/ | grep cron   >> $CREATE_FILE 2>&1
		ls -al /etc/cron.d/ | grep cron  >> $CREATE_FILE 2>&1	
		ls -alL /var/spool/cron/*  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		;;
	AIX)
		ls -al /etc/ | grep cron   >> $CREATE_FILE 2>&1
		ls -al /etc/cron.d/ | grep cron  >> $CREATE_FILE 2>&1
		ls -alL /var/spool/cron/*  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ls -al /etc/ | grep cron   >> $CREATE_FILE 2>&1
		ls -al /etc/cron.d/ | grep cron  >> $CREATE_FILE 2>&1
		ls -alL /var/spool/cron/*  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-082] 시스템 디렉토리 권한설정 미비"
echo "[SRV-082] 시스템 디렉토리 권한설정 미비" >> $CREATE_FILE 2>&1
echo "[CHECK] : 각 디렉토리에 대해서 권한 설정 확인" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-082" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al / | egrep "bin|sbin|home|tmp|lib|usr|var|boot" >> $CREATE_FILE 2>&1 
		ls -al /usr | egrep "bin|local" >> $CREATE_FILE 2>&1 
		echo " " >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al / | egrep "bin|sbin|home|tmp|lib|usr|var|boot" >> $CREATE_FILE 2>&1 
		ls -al /usr | egrep "bin|local" >> $CREATE_FILE 2>&1 
		;;
	AIX)
		ls -al / | egrep "bin|sbin|home|tmp|lib|usr|var|boot" >> $CREATE_FILE 2>&1 
		ls -al /usr | egrep "bin|local" >> $CREATE_FILE 2>&1 
		;;
	HP-UX)
		ls -al / | egrep "bin|sbin|home|tmp|lib|usr|var|boot" >> $CREATE_FILE 2>&1 
		ls -al /usr | egrep "bin|local" >> $CREATE_FILE 2>&1 
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-083] 시스템 스타트업 스크립트 권한 설정 오류"
echo "[SRV-083] 시스템 스타트업 스크립트 권한 설정 오류" >> $CREATE_FILE 2>&1
echo "[CHECK] : 조건을 잘 모르겠음" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-083" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo "group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /etc/init.d/ -perm -20 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /etc/init.d/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo "/etc/init.d/ group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /etc/init.d/ -perm -20 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/init.d/ other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /etc/init.d/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/rc.d/init.d/ group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /etc/rc.d/init.d/ -perm -20 -exec ls -al {} \; >>$CREATE_FILE 2>&1
		echo "/etc/rc.d/init.d/ other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /etc/rc.d/init.d/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		;;
	AIX)
		echo "/etc/init.d/ group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /etc/init.d/ -perm -20 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/init.d/ other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /etc/init.d/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/inittab group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /etc/inittab/ -perm -20 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/inittab/ other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /etc/inittab/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/rc.d/rc2.d/ group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /etc/rc.d/rc2.d/ -perm -20 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/rc.d/rc2.d/ other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /etc/rc.d/rc2.d/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/rc.d/init.d/ group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /etc/rc.d/init.d/ -perm -20 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/etc/rc.d/init.d/ other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /etc/rc.d/init.d/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo "/sbin/init.d/ group 쓰기 권한" >> $CREATE_FILE 2>&1
		find /sbin/init.d/ -perm -20 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		echo "/sbin/init.d/ other 쓰기 권한" >> $CREATE_FILE 2>&1 
		find /sbin/init.d/ -perm -2 -exec ls -al {} \; >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-087] C 컴파일러 존재 및 권한 설정 오류"
echo "[SRV-087] C 컴파일러 존재 및 권한 설정 오류" >> $CREATE_FILE 2>&1
echo "[CHECK] : gcc가 존재하지 않으면 양호, 존재한다면 권한 설정이 XXX이하이면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-087" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al /usr/bin | grep gcc >> $CREATE_FILE 2>&1
		;;
	Linux)
		ls -al /usr/bin | grep gcc >> $CREATE_FILE 2>&1 
		;;
	AIX)
		ls -al /usr/local/bin | grep gcc >> $CREATE_FILE 2>&1 
		ls -al /usr/vacpp/bin/xlc | grep xlc >> $CREATE_FILE 2>&1 
		ls -al /usr/vacpp/bin/xlC | grep xlC >> $CREATE_FILE 2>&1 
		ls -al /usr/vac/bin/cc >> $CREATE_FILE 2>&1 
		;;
	HP-UX)
		ls -al /usr/local | grep gcc >> $CREATE_FILE 2>&1 
		ls -al /opt/hp-gcc/bin | grep gcc >> $CREATE_FILE 2>&1 
		ls -al /opt/aCC/bin >> $CREATE_FILE 2>&1 
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-094] Crontab 참조파일 권한 설정 오류"
echo "[SRV-094] Crontab 참조파일 권한 설정 오류" >> $CREATE_FILE 2>&1
echo "[CHECK] : other 쓰기 권한이 있는 경우 취약 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-094" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		find /etc/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		;;
	Linux)
		find /etc/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		find /usr/bin/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		find /var/spool/cron/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		;;
	AIX)
		find /etc/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		find /usr/bin/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		find /var/spool/cron/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		;;
	HP-UX)
		find /etc/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		find /usr/bin/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		find /var/spool/cron/cron* -type f -perm -002 -exec ls -al {} \; >> $CREATE_FILE 2>&1 
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-100] xterm 실행 파일 권한 설정"
echo "[SRV-100] xterm 실행 파일 권한 설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : 설치가 되어 있지 않거나 권한이 600이면 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-100" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ls -al /usr/bin/xterm >> $CREATE_FILE 2>&1 		
		;;
	Linux)
		ls -al /usr/bin/xterm >> $CREATE_FILE 2>&1 
		;;
	AIX)
		ls -al /usr/bin/xterm >> $CREATE_FILE 2>&1 
		;;
	HP-UX)
		ls -al /usr/bin/xterm >> $CREATE_FILE 2>&1 
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-108] 과도한 시스템 로그파일 권한 설정"
echo "[SRV-108] 과도한 시스템 로그파일 권한 설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : 할당된 권한이 640 이상 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-108" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo /var/log 서비스로그 권한 확인 >> $CREATE_FILE 2>&1
		ls -al /var/log	>> $CREATE_FILE 2>&1	
		echo /var/adm 운영로그 권한 확인 >> $CREATE_FILE 2>&1
		ls -al /var/adm	>> $CREATE_FILE 2>&1	
		;;
	Linux)
		touch fasoo_syslog
		case $Linux_OS in
		centos)
			cat $SYS_PATH | grep "/var/log" | sed '$d' >> fasoo_syslog
			cat $SYS_PATH2 | grep "/var/log" | sed '$d' >> fasoo_syslog
			;;
		ubuntu)
			cat $SYS_PATH | grep /var/log | sed 's/-//' | grep -v '#' >> fasoo_syslog
			cat $SYS_PATH2 | grep /var/log | sed 's/-//' | grep -v '#' >> fasoo_syslog
			echo "주석 처리" >> $CREATE_FILE 2>&1
			cat $SYS_PATH | grep /var/log | sed 's/-//' | grep '#' >> $CREATE_FILE 2>&1
			cat $SYS_PATH2 | grep /var/log | sed 's/-//' | grep '#' >> $CREATE_FILE 2>&1
			echo "활성화" >> $CREATE_FILE 2>&1
			;;
		esac
		while read A B
		do
			echo "$B" >> $CREATE_FILE 2>&1
			ls -al $B >> $CREATE_FILE 2>&1
		done < fasoo_syslog
		rm -rf fasoo_*
		echo " " >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo 시스템 로그파일 권한 확인 >> $CREATE_FILE 2>&1
		ls -ald /var/log/wtmp /var/log/utmp /var/log/btmp /var/log/pacct /var/log/messages /var/log/lastlog /var/log/secure >> $CREATE_FILE 2>&1	
		echo " " >> $CREATE_FILE 2>&1
		ls -ald /var/adm /etc/security /etc/utmp >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo 시스템 로그파일 권한 확인 >> $CREATE_FILE 2>&1
		ls -ald /var/log/wtmp /var/log/utmp /var/log/btmp /var/log/pacct /var/log/messages /var/log/lastlog /var/log/secure >> $CREATE_FILE 2>&1	
		echo " " >> $CREATE_FILE 2>&1
		ls -ald /var/adm /etc/utmp >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-112] Cron 서비스 실행 로깅 미설정"
echo "[SRV-112] Cron 서비스 실행 로깅 미설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : Cron 서비스에 대한 로깅이 되어 있으면 양호 되어 있지 않으면 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-112" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo cron 목록 조회 >> $CREATE_FILE 2>&1
		crontab -l >> $CREATE_FILE 2>&1 	
		echo cron 로그 확인 >> $CREATE_FILE 2>&1
		cat /var/cron/log  >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/default/cron | grep -i "CRONLOG" >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo NA >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo NA >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo NA >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-114] 로그인 실패 감사 기능 미설정"
echo "[SRV-114] 로그인 실패 감사 기능 미설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : 감사 설정과 log파일이 생성되어 있으면 양호 설정 및 log파일이 생성되어 있지 않으면 취약" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-114" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo 감사 정책 확인  >> $CREATE_FILE 2>&1
		cat /etc/default/login >> $CREATE_FILE 2>&1 	
		echo 감사 로그 확인 >> $CREATE_FILE 2>&1
		cat /var/adm/loginlog  >> $CREATE_FILE 2>&1 
		;;
	Linux)
		echo NA >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo NA >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo NA >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1


echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-133] cron 파일 내 계정 미존재"
echo "[SRV-133] cron 파일 내 계정 미존재" >> $CREATE_FILE 2>&1
echo "[CHECK] : cron.allow 값이 없으면 취약 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-133" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		cat /etc/cron.allow >> $CREATE_FILE 2>&1 
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/cron.deny >> $CREATE_FILE 2>&1
		;;
	Linux)
		cat /etc/cron.allow >> $CREATE_FILE 2>&1 
		echo " " >> $CREATE_FILE 2>&1 
		cat /etc/cron.deny >> $CREATE_FILE 2>&1
		;;
	AIX)
		cat /etc/cron.allow >> $CREATE_FILE 2>&1 
		echo " " >> $CREATE_FILE 2>&1 
		cat /etc/cron.deny >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		cat /etc/cron.allow >> $CREATE_FILE 2>&1 
		echo " " >> $CREATE_FILE 2>&1 
		cat /etc/cron.deny >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-134] 스택 영역 실행 방지 미설정"
echo "[SRV-134] 스택 영역 실행 방지 미설정" >> $CREATE_FILE 2>&1
echo "[CHECK] : set noexec_user_stack=1 설정확인" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-134" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo /etc/system 설정 확인  >> $CREATE_FILE 2>&1
		cat /etc/system >> $CREATE_FILE 2>&1 	 
		;;
	Linux)
		echo NA >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo NA >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo NA >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1


echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-135] TCP ISS 설정 여부"
echo "[SRV-135] TCP ISS 설정 여부" >> $CREATE_FILE 2>&1
echo "[CHECK] : TCP_STRONG_ISS 설정값이 2인 경우 양호" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-135" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo /etc/default/inetinit 설정 확인  >> $CREATE_FILE 2>&1
		cat /etc/default/inetinit >> $CREATE_FILE 2>&1 	 
		;;
	Linux)
		echo NA >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo NA >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo NA >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1


echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-162] 이벤트 로그에 대한 접근 권한 설정 미비"
echo "[SRV-162] 이벤트 로그에 대한 접근 권한 설정 미비" >> $CREATE_FILE 2>&1
echo "[CHECK] : 3개의 값중 sulog에 대한 설정이 하나라도 없으면 취약 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-162" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		echo /etc/default/su에서 su로그 설정확인   >> $CREATE_FILE 2>&1
		cat /etc/default/su 			   >> $CREATE_FILE 2>&1		
		echo /var/adm/sulog sulog 확인  >> $CREATE_FILE 2>&1  
		cat /var/adm/sulog		>> $CREATE_FILE 2>&1
		ls -al /etc/default/su 		>> $CREATE_FILE 2>&1
		ls -al /var/adm/sulog 		>> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		;;
	Linux)
		echo "1" >> $CREATE_FILE 2>&1 
		cat /etc/login.defs | grep SULOG_FILE >> $CREATE_FILE 2>&1 
		echo "2" >> $CREATE_FILE 2>&1 
		cat $SYS_PATH2 | grep authpriv.info >> $CREATE_FILE 2>&1 
		cat $SYS_PATH | grep authpriv.info >> $CREATE_FILE 2>&1 
		echo "3" >> $CREATE_FILE 2>&1 
		cat /etc/logrotate.d/syslog | grep log | egrep -v "cron|maillog|secure|spooler|messages|kill" >> $CREATE_FILE 2>&1 
		echo " " >> $CREATE_FILE 2>&1 
		;;
	AIX)
		echo NA >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		echo NA >> $CREATE_FILE 2>&1
		;;
esac
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "============================================"  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "[SRV-158] 불필요한 TELNET 서비스 구동 여부"  
echo "[SRV-158] 불필요한 TELNET 서비스 구동 여부"  >> $CREATE_FILE 2>&1
echo "[CHECK]  TELNET 서비스를 비활성이면 양호 " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "▶▶ SRV-158" >> $CREATE_FILE 2>&1
case $OS in
	SunOS)
		ps -ef | egrep -i "TELNET" | grep -v "grep" >> $CREATE_FILE 2>&1
		inetadm | egrep -i "TELNET" | grep -v "grep" >> $CREATE_FILE 2>&1
		svcs -a | egrep -i "TELNET" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	Linux)
		ps -ef | egrep -i "TELNET" | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/TELNET >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/TELNET >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		cat /etc/xinetd.d/TELNET >> $CREATE_FILE 2>&1
		;;
	AIX)
		ps -ef | egrep -i "TELNET" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
	HP-UX)
		ps -ef | egrep -i "TELNET" | grep -v "grep" >> $CREATE_FILE 2>&1
		;;
esac	
echo "END" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1



echo "============================================"  >> $CREATE_FILE 2>&1
echo "************************************************** END *************************************************"   >> $CREATE_FILE 2>&1
date   >> $CREATE_FILE 2>&1
echo "************************************************** END *************************************************"  >> $CREATE_FILE 2>&1
echo "☞ USIM 진단툴_UNIX 작업이 완료되었습니다."  >> $CREATE_FILE 2>&1
echo "☞ 스크립트 결과 파일을 FASOO 직원에게 전달 바랍니다."  >> $CREATE_FILE 2>&1
echo "☞ 수고하셨습니다."  >> $CREATE_FILE 2>&1
echo "☞ 감사합니다."  >> $CREATE_FILE 2>&1

echo "************************************************** END *************************************************"